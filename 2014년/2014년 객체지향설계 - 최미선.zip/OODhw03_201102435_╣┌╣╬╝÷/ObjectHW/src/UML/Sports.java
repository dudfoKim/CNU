package UML;

public class Sports {
	String name;
	int playerNum;
}
