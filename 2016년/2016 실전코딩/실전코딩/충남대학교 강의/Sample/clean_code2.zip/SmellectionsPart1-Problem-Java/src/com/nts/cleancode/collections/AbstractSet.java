package com.nts.cleancode.collections;

public abstract class AbstractSet extends AbstractCollection {
}
