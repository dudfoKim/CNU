// ***************************************************************************
// Copyright (c) 2012, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

#include <gtest/gtest.h>
#include <string>

#include "Tail.h"

using namespace std;

class TailTest : public testing::Test
{
};

TEST_F(TailTest, yourFirstTest)
{
	ASSERT_EQ("write some", "tests here");
}
