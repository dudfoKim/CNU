/******************************************************************************
 *  
 * Copyright (c) 2007, Industrial Logic, Inc., All Rights Reserved.
 * 
 * This code is the exclusive property of Industrial Logic, Inc. It may only be
 * used in Industrial Logic's workshops, by Industrial Logic staff, for teaching
 * purposes. This code may not be used for any other purpose without the prior
 * written consent of Industrial Logic, Inc.
 * 
 ******************************************************************************/

#include "Date.h"
#include "assert.h"

Date::Date()
{
	time_t t;
	::time(&t);
	setTime(t);
}

Date::Date(time_t seconds)
{
	setTime(seconds);
}

time_t Date::getTime() const
{
	return m_Time;
}

void Date::setTime(time_t seconds)
{
	m_Time = seconds;
}

bool Date::before(const Date& other) const
{
	return ::difftime(getTime(), other.getTime()) < 0.0;
}

bool Date::after(const Date& other) const
{
	return ::difftime(getTime(), other.getTime()) > 0.0;
}

bool Date::operator==(const Date& other) const
{
	return getTime() == other.getTime();
}

bool Date::operator<(const Date& other) const
{
	return this->before(other);
}

std::ostream& operator<<(std::ostream& ostrm, const Date& aDate)
{
	ostrm << " Date(" << (long)aDate.getTime() << ") ";
	return ostrm;
}
