/******************************************************************************
 *
 * Copyright (c) 2007, Industrial Logic, Inc., All Rights Reserved.
 *
 * This code is the exclusive property of Industrial Logic, Inc. It may only be
 * used in Industrial Logic's workshops, by Industrial Logic staff, for teaching
 * purposes. This code may not be used for any other purpose without the prior
 * written consent of Industrial Logic, Inc.
 *
 ******************************************************************************/

#ifndef TAIL_QUEUE_H_
#define TAIL_QUEUE_H_

#include "Tail.h"
#include <stdio.h>

class TailAlreadyInQueueException : public std::exception
{
public:
	TailAlreadyInQueueException(int id)
	{
		sprintf(message, "Tail with id %d is already in the queue.", id);
	}

	~TailAlreadyInQueueException() throw()
	{
	}

	const char* what() const throw()
	{
		return message;
	}

private:
	char message[100];
};

class TailNotFoundException : public std::exception
{
public:
	TailNotFoundException()
	{
	}

	~TailNotFoundException() throw()
	{
	}

	const char* what() const throw()
	{
		return "Not in the queue";
	}
};

typedef std::set<Tail> TailSet;

class TailQueue
{
private:
	int m_state;
	TailSet m_queues[4];

public:
	TailQueue();
	virtual ~TailQueue();

	virtual Tail get();

	virtual Tail getNextInRotation();

	virtual void add(const Tail& tail);
	virtual bool isQueued(const Tail& tail);

private:
	// throws exception notFoundException if not found
	Tail get(int firstChoice, int secondChoice, int nextState);
	Tail dequeue(int queueNumber);

private:
	bool contains(const TailSet& queue, const Tail& tail);

	TailQueue(const TailQueue& rhs); // don't implement
	TailQueue& operator=(const TailQueue& rhs); // don't implement
};

#endif
