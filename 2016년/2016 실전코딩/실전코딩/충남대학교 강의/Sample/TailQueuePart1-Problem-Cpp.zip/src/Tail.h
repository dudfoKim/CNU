/******************************************************************************
 *  
 * Copyright (c) 2007, Industrial Logic, Inc., All Rights Reserved.
 * 
 * This code is the exclusive property of Industrial Logic, Inc. It may only be
 * used in Industrial Logic's workshops, by Industrial Logic staff, for teaching
 * purposes. This code may not be used for any other purpose without the prior
 * written consent of Industrial Logic, Inc.
 * 
 ******************************************************************************/

#ifndef TAIL_H_
#define TAIL_H_

#include "Date.h"
#include <set>

class Tail
{
public:
	enum Priority
	{
		URGENT = 0,
		IMPORTANT = 1,
		REQUESTING = 2,
		DISMISSED = 3
	};

	int m_id;
	Priority m_priorityClass;
	Date m_lastContactTime;

	Tail(int identity, Priority priorityClass, const Date& lastContactTime);

	virtual ~Tail();

	virtual int compareTo(const Tail& other) const;
	
	bool operator<(const Tail& other) const;
	bool operator==(const Tail& other) const;
};

inline std::ostream& operator<<(std::ostream& outStream, const Tail& tail)
{
	outStream << "Tail("
			  << tail.m_id 
              << ", "
			  << tail.m_priorityClass
              << ", "
			  << tail.m_lastContactTime
			  << ")";
	return outStream;
} 

#endif
