/******************************************************************************
*
* Copyright (c) 2007, Industrial Logic, Inc., All Rights Reserved.
*
* This code is the exclusive property of Industrial Logic, Inc. It may only be
* used in Industrial Logic's workshops, by Industrial Logic staff, for teaching
* purposes. This code may not be used for any other purpose without the prior
* written consent of Industrial Logic, Inc.
*
******************************************************************************/

#include "TailQueue.h"

#define ARRAY_SIZE(arr) (sizeof((arr))/sizeof((arr)[0]))

enum {
	STATE_IMPORTANT_FIRST = 0,
	STATE_REQUESTING = 1,
	STATE_IMPORTANT_SECOND = 2
};

TailQueue::TailQueue()
	: m_state(STATE_IMPORTANT_FIRST)
{
}

TailQueue::~TailQueue()
{
}

Tail TailQueue::get()
{
	if (m_queues[Tail::URGENT].empty())
		return getNextInRotation();
	return dequeue(Tail::URGENT);
}

Tail TailQueue::getNextInRotation()
{
	switch (m_state)
	{
		case STATE_IMPORTANT_FIRST:
			return get(Tail::IMPORTANT, Tail::REQUESTING, STATE_REQUESTING);
		case STATE_REQUESTING:
			return get(Tail::REQUESTING, Tail::IMPORTANT, STATE_IMPORTANT_SECOND);
		case STATE_IMPORTANT_SECOND:
		default:
			return get(Tail::IMPORTANT, Tail::REQUESTING, STATE_IMPORTANT_FIRST);
	}
}

Tail TailQueue::get(int firstChoice, int secondChoice, int nextState)
{
	if (!m_queues[firstChoice].empty())
	{
		m_state = nextState;
		return dequeue(firstChoice);
	}
	if (!m_queues[secondChoice].empty())
		return dequeue(secondChoice);
	if (!m_queues[Tail::DISMISSED].empty())
		return dequeue(Tail::DISMISSED);

	throw TailNotFoundException();
}

Tail TailQueue::dequeue(int queueNumber)
{
	TailSet::iterator first = m_queues[queueNumber].begin();
	Tail result = *first;
	m_queues[queueNumber].erase(first);
	return result;
}

void TailQueue::add(const Tail& tail)
{
	if (isQueued(tail))
		throw TailAlreadyInQueueException(tail.m_id);
	m_queues[tail.m_priorityClass].insert(tail);
}

bool TailQueue::isQueued(const Tail& tail)
{
	for (int queueNumber = 0; queueNumber < ARRAY_SIZE(m_queues); queueNumber++)
		if (contains(m_queues[queueNumber], tail))
			return true;

	return false;
}

bool TailQueue::contains(const TailSet& queue, const Tail& tail)
{
	return queue.find(tail) != queue.end();
}
