/******************************************************************************
 *  
 * Copyright (c) 2007, Industrial Logic, Inc., All Rights Reserved.
 * 
 * This code is the exclusive property of Industrial Logic, Inc. It may only be
 * used in Industrial Logic's workshops, by Industrial Logic staff, for teaching
 * purposes. This code may not be used for any other purpose without the prior
 * written consent of Industrial Logic, Inc.
 * 
 ******************************************************************************/

#ifndef DATE_H_
#define DATE_H_

#include <time.h>
#include <iostream>

class Date
{
public:

	Date();
	Date(time_t seconds);
	
	time_t getTime() const;
	void setTime(time_t seconds);
	
	bool before(const Date& other) const;
	bool after(const Date& other) const;

	bool operator==(const Date& other) const;
	bool operator<(const Date& other) const;

private:
	time_t m_Time;
};

std::ostream& operator<<(std::ostream& ostrm, const Date& aDate);

#endif

