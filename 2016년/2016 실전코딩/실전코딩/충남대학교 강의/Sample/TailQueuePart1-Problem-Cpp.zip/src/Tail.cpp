/******************************************************************************
 *  
 * Copyright (c) 2007, Industrial Logic, Inc., All Rights Reserved.
 * 
 * This code is the exclusive property of Industrial Logic, Inc. It may only be
 * used in Industrial Logic's workshops, by Industrial Logic staff, for teaching
 * purposes. This code may not be used for any other purpose without the prior
 * written consent of Industrial Logic, Inc.
 * 
 ******************************************************************************/

#include "Tail.h"

Tail::Tail(int identity, Priority priorityClass, const Date& lastContactTime) 
	: m_id(identity),
	m_priorityClass(priorityClass), 
	m_lastContactTime(lastContactTime)
{
}

Tail::~Tail()
{
}

int Tail::compareTo(const Tail& other) const 
{
	if (m_id == other.m_id) return 0;
	if (m_priorityClass < other.m_priorityClass) return -1;
	if (m_priorityClass > other.m_priorityClass) return 1;
	if (m_lastContactTime.before(other.m_lastContactTime)) return -1;
	if (m_lastContactTime.after(other.m_lastContactTime)) return 1;
	if (m_id < other.m_id) return -1;
	return 1;
}

bool Tail::operator<(const Tail& other) const
{
	return this->compareTo(other) < 0;
}

bool Tail::operator==(const Tail& other) const
{
	return this->compareTo(other) == 0;
}
