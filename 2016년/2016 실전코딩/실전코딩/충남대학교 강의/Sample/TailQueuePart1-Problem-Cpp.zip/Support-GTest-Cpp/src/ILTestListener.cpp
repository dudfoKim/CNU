// ***************************************************************************
// Copyright (c) 2012, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

#include "ILTestListener.h"
#include "ILTestInfoWriter.h"

using testing::UnitTest;
using testing::TestCase;
using testing::TestPartResult;
using testing::TestResult;
using testing::TestInfo;

namespace IL
{

TestEventListener::TestEventListener(std::ostream* output, long timestamp)
	: output_(output), timestamp_(timestamp)
{
}

TestEventListener::~TestEventListener()
{
	delete output_;
}

// Called after the unit test ends.
void TestEventListener::OnTestEnd(const TestInfo& test_info)
{
	ILTestInfo info;
	info.testName = test_info.name();
	info.suiteName = test_info.test_case_name();

	if (test_info.result()->Failed())
		failedTests_.push_back(info);
	else
		passedTests_.push_back(info);
}

void TestEventListener::OnTestProgramEnd(const UnitTest& unitTest)
{
	TestInfoWriter writer(*output_, timestamp_);
	writer.writeNumTests(failedTests_.size() + passedTests_.size());
	writer.writeList("failed", failedTests_);
	writer.writeNumFailures(failedTests_.size());
	writer.writeList("passed", passedTests_);
	writer.writeTimeStamp();
}

} // namespace IL
