// ***************************************************************************
// Copyright (c) 2012, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

#ifndef IL_TEST_LISTENER_H_
#define IL_TEST_LISTENER_H_

#include "ILTestInfoWriter.h"
#include <gtest/gtest.h>

//#include <gtest/gtest-spi.h>
//#define GTEST_IMPLEMENTATION_ 1
//#include <gtest-internal-inl.h>
//#undef GTEST_IMPLEMENTATION_

#include <iostream>
#include <vector>
#include <string>

namespace IL
{

class TestEventListener  : public testing::TestEventListener
{
private:
	std::ostream* output_;
	long timestamp_;

	TestList failedTests_;
	TestList passedTests_;

public:
	TestEventListener(std::ostream* output, long timestamp);

	virtual ~TestEventListener();

	// Fired before any test activity starts.
	virtual void OnTestProgramStart(const testing::UnitTest& unit_test) { }

	// Fired before each iteration of tests starts.  There may be more than
	// one iteration if GTEST_FLAG(repeat) is set. iteration is the iteration
	// index, starting from 0.
	virtual void OnTestIterationStart(const testing::UnitTest& unit_test,
										int iteration) { }

	// Fired before environment set-up for each iteration of tests starts.
	virtual void OnEnvironmentsSetUpStart(const testing::UnitTest& unit_test) { }

	// Fired after environment set-up for each iteration of tests ends.
	virtual void OnEnvironmentsSetUpEnd(const testing::UnitTest& unit_test) { }

	// Fired before the test case starts.
	virtual void OnTestCaseStart(const testing::TestCase& test_case) { }

	// Fired before the test starts.
	virtual void OnTestStart(const testing::TestInfo& test_info) { }

	// Fired after a failed assertion or a SUCCESS().
	virtual void OnTestPartResult(const testing::TestPartResult& test_part_result) { }

	// Fired after the test ends.
	virtual void OnTestEnd(const testing::TestInfo& test_info);

	// Fired after the test case ends.
	virtual void OnTestCaseEnd(const testing::TestCase& test_case) { }

	// Fired before environment tear-down for each iteration of tests starts.
	virtual void OnEnvironmentsTearDownStart(const testing::UnitTest& unit_test) { }

	// Fired after environment tear-down for each iteration of tests ends.
	virtual void OnEnvironmentsTearDownEnd(const testing::UnitTest& unit_test) { }

	// Fired after each iteration of tests finishes.
	virtual void OnTestIterationEnd(const testing::UnitTest& unit_test,
									int iteration) { }

	// Fired after all test activities have ended.
	virtual void OnTestProgramEnd(const testing::UnitTest& unit_test);
};

} // end namespace IL

#endif
