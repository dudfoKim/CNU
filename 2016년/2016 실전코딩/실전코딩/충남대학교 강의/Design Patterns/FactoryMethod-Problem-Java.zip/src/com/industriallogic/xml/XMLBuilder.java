/// ***************************************************************************
/// Copyright (c) 2008, Industrial Logic, Inc., All Rights Reserved.
///
/// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
/// used by students during Industrial Logic's workshops or by individuals
/// who are being coached by Industrial Logic on a project.
///
/// This code may NOT be copied or used for any other purpose without the prior
/// written consent of Industrial Logic, Inc.
/// ****************************************************************************

package com.industriallogic.xml;

import java.util.*;

public class XMLBuilder extends AbstractBuilder {
	public XMLBuilder(String rootName) {
		init(rootName);
	}
	
	public void addAbove(String uncle) {
		if (current == root)
			throw new RuntimeException(CANNOT_ADD_ABOVE_ROOT);
		history.pop();
		boolean atRootNode = (history.size() == 1);
		if (atRootNode)
			throw new RuntimeException(CANNOT_ADD_ABOVE_ROOT);
		history.pop();
		current = history.peek();
		addBelow(uncle);
	}

	public void addAttribute(String name, String value) {
		current.addAttribute(name, value);
	}

	public void addBelow(String child) {
		XmlNode childNode = new TagNode(child);
		current.add(childNode);
		parent = current;
		current = childNode;
		history.push(current);
	}
	
	public void addBeside(String sibling) {
		if (current == root)
			throw new RuntimeException(CANNOT_ADD_BESIDE_ROOT);
		XmlNode siblingNode = new TagNode(sibling);
		parent.add(siblingNode);
		current = siblingNode;
		history.pop();
		history.push(current);
	}
	
	public void addValue(String value) {
		current.addValue(value);
	}
		
	protected void init(String rootName) {
		root = new TagNode(rootName);
		current = root;
		parent = root;
		history = new Stack<XmlNode>();
		history.push(current);
	}
	
	public void startNewBuild(String rootName) {
		init(rootName);
	}

	public String toString() {
		return root.toString();
	}
}