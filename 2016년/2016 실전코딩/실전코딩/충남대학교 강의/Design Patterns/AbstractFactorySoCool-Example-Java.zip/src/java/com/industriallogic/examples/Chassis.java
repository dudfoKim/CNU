/// ***************************************************************************
/// Copyright (c) 2008, Industrial Logic, Inc., All Rights Reserved.
///
/// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
/// used by students during Industrial Logic's workshops or by individuals
/// who are being coached by Industrial Logic on a project.
///
/// This code may NOT be copied or used for any other purpose without the prior
/// written consent of Industrial Logic, Inc.
/// ****************************************************************************

package com.industriallogic.examples;

import java.util.ArrayList;
import java.util.List;

public class Chassis extends Part {

	private List<Part> parts = new ArrayList<Part>();

	public Chassis(String brand) {
		super(brand);
	}

	public void addPart(Part part) {
		parts.add(part);
	}

	public int count() {
		int i = 0;
		for (Part p : parts)
			i += p.count();
		return ++i;
	}
}
