/// ***************************************************************************
/// Copyright (c) 2009, Industrial Logic, Inc., All Rights Reserved.
///
/// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
/// used by students during Industrial Logic's workshops or by individuals
/// who are being coached by Industrial Logic on a project.
///
/// This code may NOT be copied or used for any other purpose without the prior
/// written consent of Industrial Logic, Inc.
/// ****************************************************************************


//$CopyrightHeader()$

package com.industriallogic.loan;

import java.util.Date;

public class CapitalStrategyRCTL extends CapitalStrategy {

	protected double duration(Loan loan) {
		return weightedAverageDuration(loan) + yearsBetween(loan.getMaturity(), loan.getExpiry());
	}
	
	protected double yearsBetween(Date startDate, Date endDate) {
		return ((endDate.getTime() - startDate.getTime()) / MILLIS_PER_DAY) / DAYS_PER_YEAR; 
	}	
}
