var addEvent = document.getElementByTagName("a")[0];

console.log(addEvent);