int result;

void main()
{
   int i;
   int a;
   a = 3;
   result = 1;
   i = ((a+result)*3);
}