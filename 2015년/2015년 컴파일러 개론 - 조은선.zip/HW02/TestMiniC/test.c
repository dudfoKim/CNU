int p;

void test(int a)
{
	int k;
	k = 5;

	while(1){
		a = a+1;
		if(a = 7){
			break;	
		}
	}
	k = k + a;
	return k;
}
