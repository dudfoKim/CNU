int a;
int b;
void main()
{
   a = 3;
   b = 2;
   foo(a,b);
}
void foo(int a, int b){
   return a+b;
}
void goo()
{

}